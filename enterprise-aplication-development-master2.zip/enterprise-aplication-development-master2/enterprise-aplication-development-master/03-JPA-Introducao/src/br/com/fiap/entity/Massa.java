package br.com.fiap.entity;

public enum Massa {

	TRADICIONAL, MEDIA, INTEGRAL, SEM_GLUTEN, DOCE, VEGANA;
	
}
