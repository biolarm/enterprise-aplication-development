package br.com.fiap.entity;

public enum GeneroMotorista {

	MASCULINO, FEMININO, OUTROS
	
}
