package br.com.fiap.entity;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * T_MOTORISTA
 * 	
 * 	*nr_carteira NUMBER (PK) SEQUENCE SQ_T_VEICULO
 * 	nm_motorista VARCHAR(150)
 * 	dt_nascimento	datetime
 * 	fl_carteira		byte
 * 	ds_genero		varchar2(50)
 *
 */

@Entity
@Table(name="T_MOTORISTA")
@SequenceGenerator(name="motorista" , sequenceName="SQ_T_MOTORISTA", allocationSize = 1)
public class Motorista {
	
	@Id
	@GeneratedValue(generator="motorista", strategy= GenerationType.SEQUENCE)
	private int codigo;
	
	@Column(name="nm_motorista")
	private String nome;

	@Temporal(TemporalType.DATE)
	@Column(name="dt_nascimento")
	private Calendar dtNascimento;
	
	@Lob()
	@Column(name="fl_carteira")
	private Byte[] fotoCarteira;
	
	@Enumerated(EnumType.STRING)
	@Column(name="ds_genero")
	private GeneroMotorista genero;
	

	public Motorista() {
		super();
	}
	
	

	public Motorista(int codigo, String nome, Calendar dtNascimento, Byte[] fotoCarteira, GeneroMotorista genero) {
		super();
		this.codigo = codigo;
		this.nome = nome;
		this.dtNascimento = dtNascimento;
		this.fotoCarteira = fotoCarteira;
		this.genero = genero;
	}

	


	public Motorista(String nome, Calendar dtNascimento, Byte[] fotoCarteira, GeneroMotorista genero) {
		super();
		this.nome = nome;
		this.dtNascimento = dtNascimento;
		this.fotoCarteira = fotoCarteira;
		this.genero = genero;
	}



	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Calendar getDtNascimento() {
		return dtNascimento;
	}

	public void setDtNascimento(Calendar dtNascimento) {
		this.dtNascimento = dtNascimento;
	}

	public Byte[] getFotoCarteira() {
		return fotoCarteira;
	}

	public void setFotoCarteira(Byte[] fotoCarteira) {
		this.fotoCarteira = fotoCarteira;
	}

	public GeneroMotorista getGenero() {
		return genero;
	}

	public void setGenero(GeneroMotorista genero) {
		this.genero = genero;
	}
	
	
	

}
