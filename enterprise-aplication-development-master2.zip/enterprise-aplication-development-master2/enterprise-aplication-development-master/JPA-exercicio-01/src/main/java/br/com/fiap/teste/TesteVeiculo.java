package br.com.fiap.teste;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import br.com.fiap.dao.VeiculoDAO;
import br.com.fiap.dao.impl.VeiculoDAOImpl;
import br.com.fiap.entity.Veiculo;

public class TesteVeiculo {
	
	public static void main(String[] args) {
		
		EntityManagerFactory fabrica = Persistence.createEntityManagerFactory("CLIENTE_ORACLE");
		
		EntityManager em = fabrica.createEntityManager();
		
		VeiculoDAO dao = new VeiculoDAOImpl(em);
		
		//cadastrar veic
		Veiculo veic = new Veiculo("ABC-123", "preto", 2016);
		
		try {
			dao.cadastrar(veic);
			dao.commit();
		} catch (Exception e) {
			e.printStackTrace();
		}

		//atualizar 
		veic.setCor("branco");
		
		try {
			dao.atualizar(veic);
			dao.commit();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		//buscar
		Veiculo busca = dao.buscar(1);
		System.out.println(busca.getPlaca());
		
		//deletar
		try {
			dao.deletar(1);
			dao.commit();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		em.close();
		fabrica.close();
		
	}

}
