package br.com.fiap.dao.impl;

import javax.persistence.EntityManager;

import br.com.fiap.dao.MotoristaDAO;
import br.com.fiap.entity.Motorista;

public class MotoristaDAOImpl implements MotoristaDAO {
	
	EntityManager em;

	public MotoristaDAOImpl(EntityManager em) {
		super();
		this.em = em;
	}

	@Override
	public void cadastrar(Motorista moto) {
		em.persist(moto);
	}

	@Override
	public void deletar(int codigo) {
		
		Motorista motorista = buscar(codigo);
		em.remove(codigo);
		
	}

	@Override
	public void atualizar(Motorista moto) {
		em.merge(moto);
	}

	@Override
	public Motorista buscar(int codigo) {
		return em.find(Motorista.class,codigo);
	}

	@Override
	public void commit() {
		try {
			em.getTransaction().begin();
			em.getTransaction().commit();
			
			
		} catch (Exception e) {
			// TODO: handle exception
			em.getTransaction().rollback();
		}
		
		
	}

}
