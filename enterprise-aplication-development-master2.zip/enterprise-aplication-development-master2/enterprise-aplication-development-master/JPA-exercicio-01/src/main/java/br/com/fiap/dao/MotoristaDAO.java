package br.com.fiap.dao;

import br.com.fiap.entity.Motorista;

public interface MotoristaDAO {
	
	void cadastrar(Motorista moto);
	
	void deletar(int codigo);
	
	void atualizar(Motorista moto);
	
	Motorista buscar(int codigo);
	
	void commit();

}
