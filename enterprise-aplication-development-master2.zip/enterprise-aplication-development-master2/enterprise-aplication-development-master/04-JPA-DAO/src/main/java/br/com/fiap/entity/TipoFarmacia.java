package br.com.fiap.entity;

public enum TipoFarmacia {

	MANIPULACAO, COMUM, POPULAR, DROGRARIA;
	
}
