package br.com.fiap.revisao.bean;

public enum Categoria {

	A, B, C, D, SEDAN, HATCH_ESPORTIVO
	
}